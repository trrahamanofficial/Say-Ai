SAY AI Cloudflare Pages package. Read README-BN.txt for full setup, environment variables, Supabase SQL, video status endpoint configuration and current limitations.
