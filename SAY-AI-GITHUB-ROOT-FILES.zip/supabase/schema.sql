-- SAY AI database setup. Run in Supabase SQL Editor.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'user' check (role in ('user','admin')),
  created_at timestamptz not null default now()
);
create table if not exists public.say_ai_providers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  endpoint text not null,
  model text not null,
  api_key text not null,
  enabled boolean not null default true,
  priority integer not null default 100,
  extra_headers jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
alter table public.say_ai_providers enable row level security;
-- No public policies are intentionally created. The service role is used only by Pages Functions.
-- After creating your Auth user, promote that exact user with:
-- update public.profiles set role='admin' where id=(select id from auth.users where email='YOUR_LOGIN_EMAIL');
create or replace function public.say_ai_new_profile()
returns trigger language plpgsql security definer set search_path = public as $$
begin insert into public.profiles(id, role) values (new.id, 'user') on conflict (id) do nothing; return new; end; $$;
drop trigger if exists say_ai_auth_user_created on auth.users;
create trigger say_ai_auth_user_created after insert on auth.users for each row execute procedure public.say_ai_new_profile();

-- Separate image/video providers; API keys remain server-side.
create table if not exists public.say_ai_media_providers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  media_type text not null check (media_type in ('image','video')),
  endpoint text not null,
  model text not null,
  api_key text not null,
  size text,
  enabled boolean not null default true,
  priority integer not null default 100,
  extra_headers jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
alter table public.say_ai_media_providers enable row level security;

-- Video job tracking and provider status polling. Safe to run after the earlier schema.
alter table public.say_ai_media_providers add column if not exists status_endpoint text;
create table if not exists public.say_ai_video_jobs (
  id uuid primary key default gen_random_uuid(),
  provider_id uuid references public.say_ai_media_providers(id) on delete set null,
  provider_name text not null,
  provider_job_id text,
  status text not null default 'submitted',
  video_url text,
  error text,
  provider_response jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.say_ai_video_jobs enable row level security;
create index if not exists say_ai_video_jobs_created_at_idx on public.say_ai_video_jobs(created_at desc);
