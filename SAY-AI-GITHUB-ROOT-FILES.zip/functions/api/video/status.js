const json=(data,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
async function db(env,path,options={}){const r=await fetch(`${env.SUPABASE_URL}/rest/v1/${path}`,{...options,headers:{apikey:env.SUPABASE_SERVICE_ROLE_KEY,Authorization:`Bearer ${env.SUPABASE_SERVICE_ROLE_KEY}`,'Content-Type':'application/json',Prefer:'return=representation',...(options.headers||{})}});const t=await r.text();if(!r.ok)throw Error(`Database error ${r.status}`);return t?JSON.parse(t):[]}
function statusOf(d){return String(d.status||d.state||d.data?.status||d.data?.state||'processing').toLowerCase()}
function urlOf(d){return d.video_url||d.output_url||d.url||d.data?.video_url||d.data?.output_url||d.data?.url||d.output?.video_url||d.output?.url||d.data?.output?.url||null}
function terminal(s){return ['completed','complete','succeeded','success','ready','failed','error','cancelled','canceled'].includes(s)}
export async function onRequestGet({request,env}){try{
 if(!env.SUPABASE_URL||!env.SUPABASE_SERVICE_ROLE_KEY)return json({error:'Server environment is incomplete.'},503);
 const id=new URL(request.url).searchParams.get('id');if(!id||!/^[0-9a-f-]{36}$/i.test(id))return json({error:'A valid job ID is required.'},400);
 const rows=await db(env,`say_ai_video_jobs?select=*&id=eq.${encodeURIComponent(id)}&limit=1`);const job=rows?.[0];if(!job)return json({error:'Video job not found.'},404);
 if(job.video_url||terminal(String(job.status||'').toLowerCase()))return json({jobId:id,status:job.status,videoUrl:job.video_url,error:job.error||null,provider:job.provider_name});
 const providers=await db(env,`say_ai_media_providers?select=*&id=eq.${encodeURIComponent(job.provider_id)}&limit=1`),p=providers?.[0];
 if(!p?.status_endpoint||!job.provider_job_id)return json({jobId:id,status:job.status||'submitted',videoUrl:null,provider:job.provider_name,needsProviderStatusSetup:true,message:'Add a status endpoint for this video provider to enable automatic result checking.'});
 const statusUrl=p.status_endpoint.replaceAll('{job_id}',encodeURIComponent(job.provider_job_id));
 let parsed;try{const u=new URL(statusUrl);if(u.protocol!=='https:')throw Error('Status endpoint must use HTTPS.');const r=await fetch(u.toString(),{headers:{Authorization:`Bearer ${p.api_key}`,...(p.extra_headers||{})}});parsed=await r.json().catch(()=>({}));if(!r.ok)throw Error(parsed.error?.message||parsed.message||`Provider status request failed (${r.status})`)}catch(e){return json({jobId:id,status:job.status||'processing',videoUrl:null,provider:job.provider_name,error:e.message},502)}
 const status=statusOf(parsed),videoUrl=urlOf(parsed),err=parsed.error?.message||parsed.message||null;
 await db(env,`say_ai_video_jobs?id=eq.${encodeURIComponent(id)}`,{method:'PATCH',body:JSON.stringify({status,video_url:videoUrl,error:err,provider_response:parsed,updated_at:new Date().toISOString()})});
 return json({jobId:id,status,videoUrl,error:err,provider:job.provider_name});
 }catch(e){return json({error:e.message||'Could not check video status.'},500)}}
