const json=(data,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
async function db(env,path,options={}){const r=await fetch(`${env.SUPABASE_URL}/rest/v1/${path}`,{...options,headers:{apikey:env.SUPABASE_SERVICE_ROLE_KEY,Authorization:`Bearer ${env.SUPABASE_SERVICE_ROLE_KEY}`,'Content-Type':'application/json',Prefer:'return=representation',...(options.headers||{})}});const t=await r.text();if(!r.ok)throw Error(`Database error ${r.status}: ${t.slice(0,250)}`);return t?JSON.parse(t):[]}
function getJobId(d){return d.id||d.job_id||d.data?.id||d.task_id||d.data?.task_id||null}
function getStatus(d){return String(d.status||d.state||d.data?.status||d.data?.state||'processing').toLowerCase()}
function getVideoUrl(d){return d.video_url||d.output_url||d.url||d.data?.video_url||d.data?.output_url||d.data?.url||d.output?.video_url||d.output?.url||d.data?.output?.url||null}
export async function onRequestPost({request,env}){try{
 if(!env.SUPABASE_URL||!env.SUPABASE_SERVICE_ROLE_KEY)return json({error:'Server environment is incomplete.'},503);
 const b=await request.json(),prompt=String(b.prompt||'').trim(),duration=Number(b.duration||20);
 if(!prompt)return json({error:'Video prompt is required.'},400);if(prompt.length>4000)return json({error:'Prompt is too long.'},413);if(!Number.isInteger(duration)||duration<20||duration>120)return json({error:'Duration must be between 20 and 120 seconds.'},400);
 const rows=await db(env,'say_ai_media_providers?select=*&media_type=eq.video&enabled=eq.true&order=priority.asc');if(!rows.length)return json({error:'No video provider is enabled yet. Add a compatible video provider in Admin.'},503);
 let last='Video provider could not start the job.';
 for(const p of rows){try{
  const r=await fetch(p.endpoint,{method:'POST',headers:{Authorization:`Bearer ${p.api_key}`,'Content-Type':'application/json',...(p.extra_headers||{})},body:JSON.stringify({model:p.model,prompt,duration_seconds:duration,image_url:b.imageUrl||undefined})});
  const d=await r.json().catch(()=>({}));if(!r.ok){last=d.error?.message||d.message||`Video provider returned ${r.status}`;continue;}
  const providerJobId=getJobId(d),status=getStatus(d),videoUrl=getVideoUrl(d);
  const saved=await db(env,'say_ai_video_jobs',{method:'POST',body:JSON.stringify({provider_id:p.id,provider_name:p.name,provider_job_id:providerJobId,status,video_url:videoUrl,provider_response:d})});
  const job=saved?.[0];return json({jobId:job?.id,provider:p.name,status,videoUrl,message:videoUrl?'Video is ready.':'Video job submitted; SAY AI will check its status.'},202);
 }catch(e){last=e.message||last;}}
 return json({error:last},502);
 }catch(e){return json({error:e.message||'Video service error.'},500)}}
