const json = (data, status = 200) => Response.json(data, { status, headers: { 'Cache-Control': 'no-store' } });
async function supabase(env, path, options = {}) {
  const response = await fetch(`${env.SUPABASE_URL}/rest/v1/${path}`, {
    ...options,
    headers: { apikey: env.SUPABASE_SERVICE_ROLE_KEY, Authorization: `Bearer ${env.SUPABASE_SERVICE_ROLE_KEY}`, 'Content-Type': 'application/json', ...(options.headers || {}) }
  });
  const body = await response.text();
  if (!response.ok) throw new Error(`Supabase request failed (${response.status}): ${body.slice(0, 300)}`);
  return body ? JSON.parse(body) : null;
}
export async function onRequestPost({ request, env }) {
  try {
    if (!env.SUPABASE_URL || !env.SUPABASE_SERVICE_ROLE_KEY) return json({ error: 'Backend environment is incomplete.' }, 503);
    const body = await request.json();
    const message = String(body.message || '').trim();
    if (!message) return json({ error: 'Message is required.' }, 400);
    if (message.length > 12000) return json({ error: 'Message is too long.' }, 413);
    const providers = await supabase(env, 'say_ai_providers?select=*&enabled=eq.true&order=priority.asc');
    if (!providers?.length) return json({ error: 'No enabled AI provider. Add one from the private admin dashboard.' }, 503);
    let lastError = 'No provider could answer.';
    for (const p of providers) {
      try {
        if (!p.api_key || !p.endpoint || !p.model) continue;
        const r = await fetch(p.endpoint, {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${p.api_key}`, 'Content-Type': 'application/json', ...(p.extra_headers || {}) },
          body: JSON.stringify({ model: p.model, messages: [{ role: 'user', content: message }], temperature: 0.7 })
        });
        const d = await r.json().catch(() => ({}));
        if (!r.ok) { lastError = d.error?.message || d.error || `Provider ${p.name} returned ${r.status}`; continue; }
        const answer = d.choices?.[0]?.message?.content || d.output_text || d.response || d.content?.[0]?.text;
        if (answer) return json({ answer: typeof answer === 'string' ? answer : JSON.stringify(answer), provider: p.name });
        lastError = `Provider ${p.name} returned an unsupported response format.`;
      } catch (e) { lastError = e.message; }
    }
    return json({ error: lastError }, 502);
  } catch (e) { return json({ error: e.message || 'Chat service error.' }, 500); }
}
