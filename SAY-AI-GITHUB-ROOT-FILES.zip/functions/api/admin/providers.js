const json = (data, status = 200) => Response.json(data, { status, headers: { 'Cache-Control': 'no-store' } });
async function db(env, path, options = {}) {
  const r = await fetch(`${env.SUPABASE_URL}/rest/v1/${path}`, { ...options, headers: { apikey: env.SUPABASE_SERVICE_ROLE_KEY, Authorization: `Bearer ${env.SUPABASE_SERVICE_ROLE_KEY}`, 'Content-Type': 'application/json', ...(options.headers || {}) } });
  const t = await r.text(); if (!r.ok) throw new Error(t || `Database error ${r.status}`); return t ? JSON.parse(t) : null;
}
async function isAdmin(request, env) {
  const token = (request.headers.get('Authorization') || '').replace(/^Bearer\s+/i, '');
  if (!token) return false;
  const userRes = await fetch(`${env.SUPABASE_URL}/auth/v1/user`, { headers: { apikey: env.SUPABASE_ANON_KEY, Authorization: `Bearer ${token}` } });
  if (!userRes.ok) return false;
  const user = await userRes.json();
  const rows = await db(env, `profiles?select=role&id=eq.${encodeURIComponent(user.id)}&limit=1`);
  return rows?.[0]?.role === 'admin';
}
export async function onRequest({ request, env }) {
  try {
    if (!env.SUPABASE_URL || !env.SUPABASE_ANON_KEY || !env.SUPABASE_SERVICE_ROLE_KEY) return json({ error: 'Server environment is incomplete.' }, 503);
    if (!await isAdmin(request, env)) return json({ error: 'Admin access required.' }, 403);
    if (request.method === 'GET') {
      const rows = await db(env, 'say_ai_providers?select=id,name,endpoint,model,enabled,priority,created_at&order=priority.asc');
      return json({ providers: rows || [] });
    }
    if (request.method === 'POST') {
      const b = await request.json();
      if (!b.name || !b.endpoint || !b.model || !b.api_key) return json({ error: 'Name, endpoint, model and API key are required.' }, 400);
      const rows = await db(env, 'say_ai_providers', { method: 'POST', headers: { Prefer: 'return=representation' }, body: JSON.stringify({ name: b.name, endpoint: b.endpoint, model: b.model, api_key: b.api_key, enabled: b.enabled !== false, priority: Number(b.priority || 100) }) });
      return json({ provider: rows?.[0] ? { id: rows[0].id, name: rows[0].name, enabled: rows[0].enabled } : null }, 201);
    }
    return json({ error: 'Method not allowed.' }, 405);
  } catch (e) { return json({ error: e.message || 'Admin API error.' }, 500); }
}
