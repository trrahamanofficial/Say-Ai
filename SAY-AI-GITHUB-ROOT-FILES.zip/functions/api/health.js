export async function onRequestGet({ env }) {
  const configured = Boolean(env.SUPABASE_URL && env.SUPABASE_ANON_KEY && env.SUPABASE_SERVICE_ROLE_KEY);
  return Response.json({ ok: true, service: 'SAY AI API', configured, timestamp: new Date().toISOString() });
}
