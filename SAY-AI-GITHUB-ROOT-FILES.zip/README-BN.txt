SAY AI — CLOUDFLARE PAGES FULLER STARTER
=======================================

এই প্যাকেজে আপনার frontend-এর সঙ্গে Cloudflare Pages Functions backend routes, Supabase SQL, login UI এবং provider management যোগ করা হয়েছে।

Routes
------
GET  /api/health
POST /api/chat
POST /api/images/generate
POST /api/video/generate
GET/POST /api/admin/providers          (admin only)
GET/POST /api/admin/media/providers   (admin only; image/video)

Cloudflare Pages setup
----------------------
এই ZIP extract করে ভিতরের say-ai-cloudflare ফোল্ডারটি Cloudflare Pages Direct Upload-এ দিন। Static build command লাগবে না। Functions ফোল্ডারটি project root-এর পাশে থাকবে।

Cloudflare Pages → Settings → Variables and Secrets-এ server-side variables দিন:
SUPABASE_URL = https://ssfxkcylqrmdrkacpive.supabase.co
SUPABASE_ANON_KEY = আপনার Supabase publishable key
SUPABASE_SERVICE_ROLE_KEY = Supabase থেকে নতুন করে rotate করা service-role secret (Secret হিসেবে)

কখনো service-role key frontend, HTML, JS, ZIP বা chat-এ দেবেন না। আগে chat-এ প্রকাশিত secret key rotate/revoke করুন।

Supabase setup
--------------
1. Supabase SQL Editor-এ supabase/schema.sql সম্পূর্ণ চালান।
2. Supabase Auth-এ আপনার user account তৈরি করুন।
3. নিজের account-কে admin করতে SQL চালান (ইমেইলটি নিজের login email দিয়ে বদলান):
   update public.profiles set role='admin'
   where id=(select id from auth.users where email='YOUR_LOGIN_EMAIL');
4. SAY AI Settings-এ Supabase URL ও publishable key এবং Cloudflare Pages-এর deployed URL-এ backend URL সংরক্ষণ করুন।
5. Settings থেকে sign in করুন। Admin role থাকলে private Admin বোতাম দেখা যাবে।

Provider setup
--------------
Admin থেকে Chat provider endpoint/model/key যোগ করুন। Chat provider endpoint OpenAI-compatible Chat Completions endpoint হতে হবে। Image provider-এ OpenAI-compatible Images endpoint (response_format=url বা b64_json) ব্যবহার করুন। Video endpoint-এ এই starter-এর JSON request contract গ্রহণ করতে হবে: model, prompt, duration_seconds; provider অনুযায়ী adapter লাগতে পারে।

গুরুত্বপূর্ণ সীমাবদ্ধতা
---------------------
- এটি Cloudflare Pages project starter; live production deployment, environment variables, Supabase SQL ও provider credentials আপনার account-এ সেট না করলে live AI কাজ করবে না।
- Image generation endpoint OpenAI-compatible image response বোঝে। অন্য vendor হলে adapter পরিবর্তন লাগবে।
- Video endpoint শুধু provider-এ job submit করে। Polling, webhook, final video retrieval ও storage এখনো vendor-specificভাবে সম্পূর্ণ করা হয়নি। 20–120 সেকেন্ডের duration validation আছে; provider নিজে সমর্থন না করলে কাজ করবে না।
- Full subscription checkout/payment verification, quota enforcement এবং cloud chat-history sync এখনো নেই।
- Admin provider key database-এ server-side রাখা হয়; service-role key শুধু Cloudflare secret-এ থাকবে।
- Login flow Supabase email/password Auth ব্যবহার করে। Guest mode local chat history-তে কাজ করে।

ভিডিও অটো-স্ট্যাটাস ও ফলাফল (নতুন)
--------------------------------
- নতুন route: GET /api/video/status?id=JOB_UUID
- ভিডিও provider যোগ করার সময় Status URL ঘরে provider-এর status endpoint দিন। URL-এ provider-এর job ID বসানোর জায়গায় {job_id} লিখুন। উদাহরণ কাঠামো: https://provider.example/v1/videos/{job_id}
- Provider status API-কে Bearer API key গ্রহণ করতে হবে এবং JSON-এ status/state ও video_url/output_url/url (অথবা data-র ভেতরে একই field) দিতে হবে। Provider ভেদে response আলাদা হলে provider adapter লাগবে।
- Generate করার পরে SAY AI সর্বোচ্চ প্রায় ৫ মিনিট পর্যন্ত প্রতি ৫ সেকেন্ডে status দেখবে। সম্পন্ন হলে ভিডিও player ও Open/Download link দেখাবে।
- Supabase SQL Editor-এ আপডেট করা supabase/schema.sql আবার সম্পূর্ণ চালান; এতে video job table ও status_endpoint column তৈরি হবে। পুরোনো schema থাকলেও ALTER/CREATE IF NOT EXISTS ব্যবহার করা হয়েছে।
- Status URL না দিলে provider job submit হবে, কিন্তু automatic result polling চালু হবে না।
